<?php
$college = [
  'name' => "S.I.W.S. N.R. Swamy College of Commerce & Economics & Smt. Thirumalai College of Science (Autonomous)",
  'motto' => "Vidya Dhanam Sarva Dhanat Pradhanam",
  'address' => "R.A. Kidwai Road, Wadala (W), Mumbai - 400031",
  'phone' => "+91-22-2413 0689",
  'email' => "siwsnrsc@gmail.com",
  'logo' => "https://www.siwscollege.edu.in/wp-content/uploads/2021/06/logo.png",
  'naac' => "NAAC Re-Accredited with 'A' Grade (CGPA 3.15)",
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= $college['name'] ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    *{margin:0;padding:0;box-sizing:border-box;scroll-behavior:smooth}
    body{font-family:"Segoe UI",Arial,sans-serif;line-height:1.6;background:#f4f6f9;color:#333;}
    a{text-decoration:none;color:#005ea4;}
    h2{color:#002b5c;margin-bottom:15px}
    section{padding:60px 20px;max-width:1100px;margin:auto}
    .container{max-width:1200px;margin:auto;padding:0 15px}

    /* Header */
    header{background:#002b5c;color:#fff;text-align:center;padding:25px}
    header img{height:80px;margin-bottom:10px}
    header h1{font-size:26px;margin-bottom:8px}
    header p{font-size:16px}

    /* Navbar */
    nav{background:#005ea4;position:sticky;top:0;z-index:1000}
    nav ul{display:flex;list-style:none;justify-content:center;flex-wrap:wrap}
    nav li a{color:#fff;padding:14px 22px;display:block;font-weight:600;transition:.3s}
    nav li a:hover{background:#003a6f;border-radius:5px}

    /* Hero */
    .hero{background:linear-gradient(rgba(0,46,91,.7),rgba(0,46,91,.7)),url('https://www.siwscollege.edu.in/wp-content/uploads/2021/06/siws_college_building.jpg');background-size:cover;background-position:center;color:#fff;text-align:center;padding:90px 20px}
    .hero h2{font-size:38px;animation:fadeIn 2s ease}
    .hero p{font-size:18px;margin-top:10px}

    @keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}

    /* Cards & Layout */
    .card{background:#fff;padding:20px;margin:15px 0;border-radius:10px;box-shadow:0 2px 6px rgba(0,0,0,0.1);transition:.3s}
    .card:hover{transform:translateY(-5px);box-shadow:0 6px 12px rgba(0,0,0,0.15)}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px}

    /* Table */
    table{width:100%;border-collapse:collapse;margin-top:15px;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,0.1)}
    th,td{padding:12px;border:1px solid #ddd}
    th{background:#005ea4;color:#fff}

    /* Gallery */
    .gallery{display:flex;flex-wrap:wrap;gap:15px;justify-content:center}
    .gallery img{width:280px;height:180px;object-fit:cover;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.2);transition:.3s}
    .gallery img:hover{transform:scale(1.05)}

    /* Footer */
    footer{background:#002b5c;color:#fff;text-align:center;padding:25px;margin-top:30px}
    footer a{color:#f4d03f;margin:0 10px}

    @media(max-width:768px){
      nav ul{flex-direction:column}
      .hero h2{font-size:28px}
    }
  </style>
</head>
<body>
  <header>
    <img src="<?= $college['logo'] ?>" alt="College Logo">
    <h1><?= $college['name'] ?></h1>
    <p><em><?= $college['motto'] ?></em></p>
    <p><?= $college['naac'] ?></p>
  </header>

  <nav>
    <ul>
      <li><a href="#about">About</a></li>
      <li><a href="#vision">Vision</a></li>
      <li><a href="#courses">Courses</a></li>
      <li><a href="#departments">Departments</a></li>
      <li><a href="#facilities">Facilities</a></li>
      <li><a href="#committees">Committees</a></li>
      <li><a href="#governance">Governance</a></li>
      <li><a href="#placements">Placements</a></li>
      <li><a href="#gallery">Gallery</a></li>
      <li><a href="#contact">Contact</a></li>
    </ul>
  </nav>

  <section class="hero">
    <h2>Welcome to <?= $college['name'] ?></h2>
    <p>A Premier Autonomous Institution Affiliated to the University of Mumbai</p>
  </section>

  <section id="about">
    <h2>About Us</h2>
    <div class="card">
      <p>Founded in 1980 (Commerce & Economics) and 1990 (Science), SIWS College has been nurturing socially responsible citizens with a blend of academics, sports, and culture. The college is affiliated to the University of Mumbai and holds an 'A' Grade by NAAC.</p>
    </div>
  </section>

  <section id="vision">
    <h2>Vision & Mission</h2>
    <div class="card">
      <p><strong>Vision:</strong> To disseminate quality education and empower youth to meet global challenges while retaining Indian ethos.</p>
      <p><strong>Mission:</strong> To impart value-based education, foster research, and promote innovation.</p>
    </div>
  </section>

  <section id="courses">
    <h2>Courses Offered</h2>
    <table>
      <tr><th>Level</th><th>Programs</th></tr>
      <tr><td>Undergraduate</td><td>B.Com, B.Sc (IT, Physics, Chemistry, Microbiology, Maths), BMS, BAF</td></tr>
      <tr><td>Postgraduate</td><td>M.Com (Accountancy, Management), M.Sc (IT, Physics, Microbiology)</td></tr>
      <tr><td>Doctoral</td><td>Ph.D. in Commerce & Microbiology</td></tr>
    </table>
  </section>

  <section id="departments">
    <h2>Departments</h2>
    <div class="grid">
      <div class="card"><h3>Commerce</h3><p>Flagship B.Com and specialized programs in management & finance.</p></div>
      <div class="card"><h3>Science</h3><p>Labs in Microbiology, Physics, Chemistry, and IT.</p></div>
      <div class="card"><h3>Management</h3><p>Professional courses like BMS, BAF with industry exposure.</p></div>
      <div class="card"><h3>Arts & Languages</h3><p>Communication, literature, and holistic development.</p></div>
    </div>
  </section>

  <section id="facilities">
    <h2>Facilities</h2>
    <ul>
      <li>Modern Laboratories</li>
      <li>Library with e-resources</li>
      <li>Digital Classrooms</li>
      <li>Sports Complex & Gymkhana</li>
      <li>Seminar Halls & Auditorium</li>
      <li>NSS, NCC, DLLE Units</li>
    </ul>
  </section>

  <section id="committees">
    <h2>Committees & Associations</h2>
    <div class="grid">
      <div class="card"><h3>NSS</h3><p>Community service and social outreach.</p></div>
      <div class="card"><h3>NCC</h3><p>National Cadet Corps training for discipline.</p></div>
      <div class="card"><h3>DLLE</h3><p>Extension education for skills & social impact.</p></div>
      <div class="card"><h3>Cultural</h3><p>Annual fests, drama, music, and dance.</p></div>
    </div>
  </section>

  <section id="governance">
    <h2>Governance (Apex Body)</h2>
    <table>
      <tr><th>Position</th><th>Name</th></tr>
      <tr><td>Chairman</td><td>Shri R. Radhakrishnan</td></tr>
      <tr><td>Vice Chairman</td><td>Dr V. Rangaraj</td></tr>
      <tr><td>General Secretary</td><td>Shri M. Ananthasubramanian</td></tr>
      <tr><td>Treasurer</td><td>Shri G. S. Subramanian</td></tr>
    </table>
  </section>

  <section id="placements">
    <h2>Placements</h2>
    <div class="card">
      <p>Students are placed in TCS, Infosys, Wipro, Accenture, and HDFC Bank. The Placement Cell offers communication training, aptitude practice, and mock interviews.</p>
    </div>
  </section>

  <section id="gallery">
    <h2>Gallery</h2>
    <div class="gallery">
      <img src="https://www.siwscollege.edu.in/wp-content/uploads/2021/06/siws_college_building.jpg" alt="Campus">
      <img src="https://www.siwscollege.edu.in/wp-content/uploads/2021/06/nss_activity.jpg" alt="NSS Activity">
      <img src="https://www.siwscollege.edu.in/wp-content/uploads/2021/06/library.jpg" alt="Library">
    </div>
  </section>

  <section id="contact">
    <h2>Contact Us</h2>
    <p><strong>Address:</strong> <?= $college['address'] ?></p>
    <p><strong>Phone:</strong> <?= $college['phone'] ?></p>
    <p><strong>Email:</strong> <a href="mailto:<?= $college['email'] ?>"><?= $college['email'] ?></a></p>
  </section>

  <footer>
    <p>© <?= date("Y") ?> <?= $college['name'] ?> | All Rights Reserved</p>
    <p>Developed using HTML, CSS & PHP</p>
  </footer>
</body>
</html>
